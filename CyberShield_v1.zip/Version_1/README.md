# CyberShield v1.0

## Description
CyberShield v1.0 is a beginner-friendly TCP Port Scanner developed in Python.

## Features
- Scan TCP ports
- Detect open and closed ports
- Save scan results
- Measure scan time
- Handle connection errors

## Technologies Used
- Python
- Socket Module

## How to Run

```bash
python3 main.py

## Developer
Apram Sandhu
